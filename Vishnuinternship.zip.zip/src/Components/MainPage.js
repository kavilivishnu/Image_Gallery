import React from 'react';

const MainPage = () => {
    return (
        <div className="main-page">
            <h2>Your Pictures</h2>
        </div>
    )
}

export default MainPage;